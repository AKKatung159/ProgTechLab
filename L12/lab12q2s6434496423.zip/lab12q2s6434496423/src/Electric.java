/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author akkatung
 */
public interface Electric {
    public final double LOW_VOLTAGE=480;
    public final double HIGH_VOLTAGE=600;
    public double getVoltage();
}
