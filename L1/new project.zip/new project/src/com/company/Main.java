package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        //Scanner sc = new Scanner(System.in);
        // System.out.print("weight : ");
        // float w = sc.nextFloat();
        // System.out.print("hight : ");
        // float h = sc.nextFloat();
        // float bmi = w / ((h / 100) *(h/100));
        // System.out.println("BMI = "+bmi);
        int a =2;
        if (a>10){
            System.out.println("1");
        }
        else if (a>5){
            System.out.println("2");
        }
        else{
            System.out.println("3");
        }
    }
}