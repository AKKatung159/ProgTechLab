/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author akkatung
 */
public class numberOfFaccourses {
    private int faccode;
    private int num =1;
    public numberOfFaccourses(int id){
        faccode = id;
    }
    public int getfaccode(){
        return faccode;
    }
    public void addnum(){
        num++;
    }
    public int getnum(){
        return num;
    }
}
